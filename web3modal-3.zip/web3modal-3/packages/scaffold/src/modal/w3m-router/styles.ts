import { css } from 'lit'

export default css`
  :host {
    display: block;
    will-change: transform, opacity;
  }
`
