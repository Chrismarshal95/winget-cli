import { css } from 'lit'

export default css`
  :host {
    position: relative;
    display: inline-block;
    width: 100%;
  }
`
