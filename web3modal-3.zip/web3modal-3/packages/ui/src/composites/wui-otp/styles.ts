import { css } from 'lit'

export default css`
  :host {
    position: relative;
    display: block;
  }
`
