import { css } from 'lit'

export default css`
  :host {
    display: block;
    width: 55px;
    height: 55px;
  }
`
