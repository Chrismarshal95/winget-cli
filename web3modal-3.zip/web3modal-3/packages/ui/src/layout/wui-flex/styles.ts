import { css } from 'lit'

export default css`
  :host {
    display: flex;
    width: inherit;
    height: inherit;
  }
`
