export function NetworksButton() {
  return <w3m-network-button />
}
