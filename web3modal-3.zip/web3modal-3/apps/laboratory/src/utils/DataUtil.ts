export const colors = [
  '#3da5ff',
  '#00b9a8',
  '#83f3b8',
  '#74dc2e',
  '#afbf8d',
  '#ffe272',
  '#f1d299',
  '#986a33',
  '#ff9351',
  '#eba39c',
  '#ff3737',
  '#a72626',
  '#ff74bc',
  '#bf51e0',
  '#414796'
]
